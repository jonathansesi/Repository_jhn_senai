from .base import *

DEBUG = True
ALLOWED_HOSTS = []
