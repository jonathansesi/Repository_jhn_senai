# projeto_loja/__init__.py
# Deixe vazio ou apenas com comentários
